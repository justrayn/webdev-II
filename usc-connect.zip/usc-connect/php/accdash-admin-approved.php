<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approved Events</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Geo:ital@0;1&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="..\css\accdash-admin-approved.css">
    <link rel="stylesheet" href="..\css\navbar.css">
    <link rel="stylesheet" href="..\css\footer.css">
</head>
<body>
<header class="header">
    <div class="navbar-container">
        <div class="logo navbar-container__logo">
            <a href="HomeView.html"><img src="..\img\logo.png" alt="USC Connect Logo"></a>
        </div>
        <nav class="nav navbar-container__nav">
            <ul class="ul-list nav__ul-list">
                <li class="list-item ul-list__list-item"><a href="HomeView.html">HOME</a></li>
                <li class="list-item ul-list__list-item"><a href="EventsView.html">EVENTS</a></li>
                <li class="list-item ul-list__list-item"><a href="OrganizationsView.html">ORGANIZATIONS</a></li>
                <li class="list-item ul-list__list-item"><a href="#">ACCOUNT</a></li>
                <li class="list-item ul-list__list-item"><a href="LoginView.html">LOG OUT</a></li>
            </ul>
        </nav>
    </div>
</header>

<div class="myevents">
    <div class="leftmain">
        <ul class="dashboard">
            <li><a href="#">Account Dashboard</a></li>
            <li><a href="Admin-Accounts.php">Accounts</a></li>
            <li><a href="#">Log out</a></li>
        </ul>
    </div>

    <div class="rightmain">
        <div class="topbar">
            <ul> 
                <li><a href="accdash-admin.php">All Events</a></li>
                <li><a href="#">Approved Events</a></li>
                <li><a href="accdash-admin-pending.php">Pending Events</a></li>
            </ul>
        </div>

        <p class="ongoing">On-going Events (1)</p>
        <table class="scndtopbar">
            <thead>
                <tr>
                    <th>EVENT NAME</th>
                    <th>STATUS</th>
                    <th>HOSTED BY</th>
                    <th>CES POINTS</th>
                </tr>
            </thead>
            <tbody class="ongoing-events-info">
                <tr>
                    <td><img src="..\img\sample2.png" alt="Description of Image 1" style="width: 40px; height: 40px;"> DCISM DISCO</td>
                    <td>Approved</td>
                    <td>CISCO</td>
                    <td>30</td>
                </tr>
            </tbody>
        </table>

        <p class="upcoming">Upcoming Events (0)</p>
        <div class="no-events">
            <p>No upcoming events yet</p>
        </div>
    </div>
</div>

<footer class="footer">
        <div class="footer-container">
            <div class="footer-container__logo">
                <a href="HomeView.html"><img src="..\img\logo.png" alt="USC Connect Logo"></a>
            </div>
            <nav class="footer-nav footer-container__footer-nav">
                <ul class="footer-ul-list">
                    <li class="footer-list-item"><a href="#">HELP</a></li>
                    <li class="footer-list-item"><a href="#">CONTACT US</a></li>
                    <li class="footer-list-item"><a href="#">JOINED EVENTS</a></li>
                    <li class="footer-list-item"><a href="#">FAQs</a></li>
                </ul>
            </nav>
            <nav class="footer-nav footer-container__footer-nav">
                <ul class="footer-ul-list">
                    <li class="footer-list-item"><a href="#">ABOUT US</a></li>
                    <li class="footer-list-item"><a href="#">REVIEWS</a></li>
                    <li class="footer-list-item"><a href="#">EVENTS</a></li>
                    <li class="footer-list-item"><a href="#">ORGANIZATIONS</a></li>
                </ul>
            </nav>
            <div class="social-links-container">
                <div class="social-links-title">
                    <h1>FOLLOW US</h1>
                </div>
                <nav class="social-links-nav">
                    <ul class="ul-social-links">
                        <li><a href="https://www.facebook.com/usccebu" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-facebook"></a></i></li>
                        <li><a href="https://www.instagram.com/uscphilippines/" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-instagram"></a></i></li>
                        <li><a href="https://x.com/i/flow/login?redirect_after_login=%2Fuscphilippines" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-twitter"></a></i></li>
                        <li><a href="https://www.youtube.com/@usccebuphilippines" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-youtube"></a></i></li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="copyright-notice">
            <p>&copy; 2024 USC Connect. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
